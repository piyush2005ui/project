import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Compass, Brain, BookOpen, MessageSquare, UserCircle } from 'lucide-react';
import SkillAssessment from './components/SkillAssessment';
import CareerPathways from './components/CareerPathways';
import ResourceLibrary from './components/ResourceLibrary';
import AIChat from './components/AIChat';
import UserProfile from './components/UserProfile';

function App() {
  const [activeTab, setActiveTab] = useState('profile');
  const [userProfile, setUserProfile] = useState(null);

  const tabs = [
    { id: 'profile', label: 'Your Profile', icon: <UserCircle className="w-5 h-5" /> },
    { id: 'assessment', label: 'Skill Assessment', icon: <Brain className="w-5 h-5" /> },
    { id: 'pathways', label: 'Career Pathways', icon: <Compass className="w-5 h-5" /> },
    { id: 'resources', label: 'Resources', icon: <BookOpen className="w-5 h-5" /> },
    { id: 'chat', label: 'AI Advisor', icon: <MessageSquare className="w-5 h-5" /> }
  ];

  const handleProfileSubmit = (profile) => {
    setUserProfile(profile);
    setActiveTab('assessment');
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'profile':
        return <UserProfile onSubmit={handleProfileSubmit} />;
      case 'assessment':
        return <SkillAssessment />;
      case 'pathways':
        return <CareerPathways userProfile={userProfile} />;
      case 'resources':
        return <ResourceLibrary />;
      case 'chat':
        return <AIChat />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Compass className="w-8 h-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">CareerCompass</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-lg shadow-md p-1">
            <div className="flex space-x-1">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center px-4 py-2 rounded-md transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {tab.icon}
                  <span className="ml-2">{tab.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
        >
          {renderContent()}
        </motion.div>
      </main>
    </div>
  );
}

export default App;