import React from 'react';
import { Rocket, Trophy, Target, TrendingUp, Code } from 'lucide-react';

const pathways = [
  {
    title: "Software Development",
    description: "Build the future through code",
    icon: <Code className="w-6 h-6" />,
    match: "95%",
    skills: ["JavaScript", "Python", "System Design"]
  },
  {
    title: "Data Science",
    description: "Transform data into insights",
    icon: <TrendingUp className="w-6 h-6" />,
    match: "88%",
    skills: ["Statistics", "Machine Learning", "SQL"]
  },
  {
    title: "Product Management",
    description: "Lead product innovation",
    icon: <Target className="w-6 h-6" />,
    match: "82%",
    skills: ["Strategy", "User Experience", "Agile"]
  },
  {
    title: "Cloud Architecture",
    description: "Design scalable solutions",
    icon: <Rocket className="w-6 h-6" />,
    match: "78%",
    skills: ["AWS", "DevOps", "Security"]
  }
];

export default function CareerPathways() {
  return (
    <div className="w-full max-w-4xl mx-auto p-6">
      <h2 className="text-3xl font-bold text-gray-800 mb-8">Recommended Career Pathways</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {pathways.map((pathway) => (
          <div key={pathway.title} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all transform hover:-translate-y-1">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                {pathway.icon}
                <h3 className="text-xl font-semibold text-gray-700">{pathway.title}</h3>
              </div>
              <span className="bg-green-100 text-green-800 text-sm font-medium px-2.5 py-0.5 rounded">
                {pathway.match} Match
              </span>
            </div>
            <p className="text-gray-600 mb-4">{pathway.description}</p>
            <div className="flex flex-wrap gap-2">
              {pathway.skills.map((skill) => (
                <span key={skill} className="bg-blue-50 text-blue-700 text-sm px-3 py-1 rounded-full">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}