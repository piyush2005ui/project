import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Brain, ChevronRight, CheckCircle } from 'lucide-react';

interface Question {
  id: number;
  text: string;
  type: string;
  options?: string[];
  category: string;
}

const questions: Question[] = [
  {
    id: 1,
    text: "How comfortable are you with problem-solving and analytical thinking?",
    type: "rating",
    category: "Technical Aptitude"
  },
  {
    id: 2,
    text: "Which area interests you the most?",
    type: "choice",
    options: ["Software Development", "Data Analysis", "Project Management", "Research"],
    category: "Innovation"
  },
  {
    id: 3,
    text: "How do you prefer to work?",
    type: "choice",
    options: ["Independently", "In small teams", "Large collaborative projects", "Mixed environment"],
    category: "Leadership"
  },
  {
    id: 4,
    text: "Rate your comfort level with learning new technologies",
    type: "rating",
    category: "Technical Aptitude"
  },
  {
    id: 5,
    text: "How important is creativity in your ideal role?",
    type: "rating",
    category: "Innovation"
  },
  {
    id: 6,
    text: "Which best describes your communication style?",
    type: "choice",
    options: ["Technical and precise", "Creative and visual", "Strategic and persuasive", "Analytical and detailed"],
    category: "Leadership"
  },
  {
    id: 7,
    text: "Rate your interest in data analysis and statistics",
    type: "rating",
    category: "Analytical Skills"
  },
  {
    id: 8,
    text: "How do you approach complex problems?",
    type: "choice",
    options: ["Break into smaller parts", "Research extensively", "Collaborate with others", "Experiment and iterate"],
    category: "Technical Aptitude"
  },
  {
    id: 9,
    text: "Rate your leadership and management interests",
    type: "rating",
    category: "Leadership"
  },
  {
    id: 10,
    text: "Which type of projects excite you the most?",
    type: "choice",
    options: ["Technical implementation", "Creative design", "Strategic planning", "Research and analysis"],
    category: "Innovation"
  },
  {
    id: 11,
    text: "How comfortable are you with public speaking and presentations?",
    type: "rating",
    category: "Leadership"
  },
  {
    id: 12,
    text: "Rate your interest in research and documentation",
    type: "rating",
    category: "Analytical Skills"
  },
  {
    id: 13,
    text: "Which work environment do you prefer?",
    type: "choice",
    options: ["Fast-paced startup", "Established corporation", "Research institution", "Consulting firm"],
    category: "Innovation"
  },
  {
    id: 14,
    text: "How important is mentoring others in your career?",
    type: "rating",
    category: "Leadership"
  },
  {
    id: 15,
    text: "Rate your interest in system architecture and design",
    type: "rating",
    category: "Technical Aptitude"
  }
];

const careerRecommendations = {
  technical: {
    title: "Technical Career Path",
    description: "Your responses indicate a strong aptitude for technical roles. You show excellent problem-solving skills and interest in technology.",
    roles: ["Software Engineer", "System Architect", "DevOps Engineer", "Technical Lead"],
    skills: ["Programming", "System Design", "Cloud Technologies", "Problem Solving"]
  },
  creative: {
    title: "Innovation-Focused Career Path",
    description: "You demonstrate strong creative thinking and innovation capabilities. Your skills align well with roles that require original solutions.",
    roles: ["UX Designer", "Product Manager", "Innovation Consultant", "Creative Technologist"],
    skills: ["Design Thinking", "User Research", "Prototyping", "Creative Problem Solving"]
  },
  management: {
    title: "Leadership Career Path",
    description: "Your profile shows strong leadership potential and excellent people skills. You're well-suited for management roles.",
    roles: ["Project Manager", "Team Lead", "Product Owner", "Department Manager"],
    skills: ["Leadership", "Team Management", "Strategic Planning", "Communication"]
  },
  research: {
    title: "Research & Analysis Career Path",
    description: "You show strong analytical capabilities and attention to detail. Research-oriented roles would suit your skills well.",
    roles: ["Data Scientist", "Research Analyst", "Business Analyst", "Market Researcher"],
    skills: ["Data Analysis", "Research Methods", "Statistical Analysis", "Critical Thinking"]
  }
};

export default function SkillAssessment() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string | number>>({});
  const [showResults, setShowResults] = useState(false);

  const handleAnswer = (answer: string | number) => {
    setAnswers({ ...answers, [currentQuestion]: answer });
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const calculateCareerPath = () => {
    let scores = {
      technical: 0,
      creative: 0,
      management: 0,
      research: 0
    };

    Object.entries(answers).forEach(([questionId, answer]) => {
      const question = questions.find(q => q.id === parseInt(questionId));
      if (question?.category === "Technical Aptitude" && typeof answer === "number") {
        scores.technical += answer;
      } else if (question?.category === "Innovation" && typeof answer === "number") {
        scores.creative += answer;
      } else if (question?.category === "Leadership" && typeof answer === "number") {
        scores.management += answer;
      } else if (question?.category === "Analytical Skills" && typeof answer === "number") {
        scores.research += answer;
      }
    });

    const maxScore = Math.max(...Object.values(scores));
    const careerPath = Object.entries(scores).find(([_, score]) => score === maxScore)?.[0] || 'technical';
    return careerRecommendations[careerPath as keyof typeof careerRecommendations];
  };

  if (showResults) {
    const recommendation = calculateCareerPath();
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8"
      >
        <div className="flex items-center gap-3 mb-6">
          <CheckCircle className="w-8 h-8 text-green-500" />
          <h2 className="text-2xl font-bold text-gray-800">Assessment Complete!</h2>
        </div>
        
        <div className="mb-8">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">{recommendation.title}</h3>
          <p className="text-gray-600 mb-6">{recommendation.description}</p>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Recommended Roles:</h4>
              <div className="flex flex-wrap gap-2">
                {recommendation.roles.map((role) => (
                  <span key={role} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                    {role}
                  </span>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Key Skills to Develop:</h4>
              <div className="flex flex-wrap gap-2">
                {recommendation.skills.map((skill) => (
                  <span key={skill} className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }

  const currentQ = questions[currentQuestion];
  return (
    <motion.div
      key={currentQuestion}
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8"
    >
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <Brain className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-gray-800">Skill Assessment</h2>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${(currentQuestion / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="mb-8">
        <h3 className="text-lg font-medium text-gray-700 mb-4">{currentQ.text}</h3>
        
        {currentQ.type === "choice" && currentQ.options && (
          <div className="space-y-3">
            {currentQ.options.map((option) => (
              <button
                key={option}
                onClick={() => handleAnswer(option)}
                className="w-full text-left p-4 rounded-lg border border-gray-200 hover:border-blue-500 hover:bg-blue-50 transition-colors flex items-center justify-between group"
              >
                <span>{option}</span>
                <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-blue-500" />
              </button>
            ))}
          </div>
        )}

        {currentQ.type === "rating" && (
          <div className="flex justify-between gap-4">
            {[1, 2, 3, 4, 5].map((rating) => (
              <button
                key={rating}
                onClick={() => handleAnswer(rating)}
                className="flex-1 aspect-square flex items-center justify-center text-lg font-medium rounded-lg border border-gray-200 hover:border-blue-500 hover:bg-blue-50 transition-colors"
              >
                {rating}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="text-sm text-gray-500">
        Question {currentQuestion + 1} of {questions.length}
      </div>
    </motion.div>
  );
}