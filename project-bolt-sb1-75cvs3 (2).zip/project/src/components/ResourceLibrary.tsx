import React from 'react';
import { BookOpen, Video, Globe, Award } from 'lucide-react';

const resources = [
  {
    title: "Online Courses",
    icon: <Globe className="w-6 h-6" />,
    items: [
      { name: "Machine Learning Specialization", platform: "Coursera", duration: "3 months" },
      { name: "Web Development Bootcamp", platform: "Udemy", duration: "6 months" },
      { name: "Data Science Fundamentals", platform: "edX", duration: "2 months" }
    ]
  },
  {
    title: "Certifications",
    icon: <Award className="w-6 h-6" />,
    items: [
      { name: "AWS Solutions Architect", platform: "Amazon", duration: "6 months" },
      { name: "Google Cloud Professional", platform: "Google", duration: "3 months" },
      { name: "PMP Certification", platform: "PMI", duration: "4 months" }
    ]
  },
  {
    title: "Video Tutorials",
    icon: <Video className="w-6 h-6" />,
    items: [
      { name: "System Design Series", platform: "YouTube", duration: "20 hours" },
      { name: "Advanced JavaScript", platform: "Frontend Masters", duration: "12 hours" },
      { name: "UI/UX Design", platform: "Skillshare", duration: "15 hours" }
    ]
  }
];

export default function ResourceLibrary() {
  return (
    <div className="w-full max-w-4xl mx-auto p-6">
      <h2 className="text-3xl font-bold text-gray-800 mb-8">Learning Resources</h2>
      <div className="grid grid-cols-1 gap-6">
        {resources.map((category) => (
          <div key={category.title} className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-6">
              {category.icon}
              <h3 className="text-xl font-semibold text-gray-700">{category.title}</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {category.items.map((item) => (
                <div key={item.name} className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors">
                  <h4 className="font-medium text-gray-800 mb-2">{item.name}</h4>
                  <div className="flex flex-col text-sm text-gray-600">
                    <span>{item.platform}</span>
                    <span>{item.duration}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}